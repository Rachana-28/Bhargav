﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMSBal;
using HMSEntities;
using HMSExceptions;


namespace HMSPL
{
    class Program
    {
        static void Main(string[] args)
        {
            HMS_BAL.SetList();
            int choice;
            do
            {
                Menu();
                Console.WriteLine("*****************************************\n");
                Console.Write("Enter your Choice :");
                choice = Int32.Parse(Console.ReadLine());
                Console.WriteLine("*****************************************\n");
                Console.WriteLine();
                switch (choice)
                {
                    case 1:
                        AddPatient();
                        break;
                    case 2:
                        ListAllPatients();
                        break;
                    case 3:
                        ModifyPatient();
                        break;
                    case 4:
                        SearchPatientByID();
                        break;
                    case 5:
                        DeletePatient();
                        break;
                    case 6:
                        AddPatientAppointmentData();
                        break;
                    case 7:
                        ListAllPatientAppointmentData();
                        break;
                    case 8:
                        SearchPatientByDoctorName();
                        break;
                    case 9:
                        SearchPatientByDoctorDOV();
                        break;
                    case 10:
                        SearchPatientByDoctorDOA();
                        break;
                    case 11:
                        SearchPatientByDoctorDOD();
                        break;
                    case 12:
                        DeletePatientAppointmentDetails();
                        break;
                    case 13:
                        AddBillReport();
                        break;
                    case 14:
                        ListAllBill();
                        break;
                    case 15:
                        SearchBillByID();
                        break;
                    case 16:
                        DeletePatientBill();
                        break;
                    case 17:
                        AddLabReport();
                        break;
                    case 18:
                        ListAllLabReport();
                        break;
                    case 19:
                        SearchReportById();
                        break;
                    case 20:
                        DeletePatientLabReport();
                        break;
                    case 21:
                        return;
                    default:
                        break;
                }

            } while ((choice > 0 && choice < 22));
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e) { SetSerialization(); }

        private static void Menu()
        {
            Console.WriteLine("\n*********** Patient Data Details ***********\n");
            Console.WriteLine("1. Add Patient Details");
            Console.WriteLine("2. List all Patient Details");
            Console.WriteLine("3. Modify Patient Details");
            Console.WriteLine("4. Search Patient by Id");
            Console.WriteLine("5. Delete Patient Details");
            Console.WriteLine("\n*********** Patient's Appointment Data Details ***********\n");
            Console.WriteLine("6. Add Patient Appointment data");
            Console.WriteLine("7. List all Patient Appointment Details");
            Console.WriteLine("8. Search Patient by Doctor Name");
            Console.WriteLine("9. Search Patient by Date of visit");
            Console.WriteLine("10. Search Patient by Date of Admission");
            Console.WriteLine("11. Search Patient by Date of Discharge");
            Console.WriteLine("12. Delete Patient's Appointment Details");
            Console.WriteLine("\n*********** Patient's Bill Data Details ***********\n");
            Console.WriteLine("13. Add Patient's Bill");
            Console.WriteLine("14. List all Patient's Bill");
            Console.WriteLine("15. Search Patient's Bill By Id");
            Console.WriteLine("16. Delete Patient's Bill Details");
            Console.WriteLine("\n*********** Patient's Lab Report Details ***********\n");
            Console.WriteLine("17. Add Patient's Lab Report");
            Console.WriteLine("18. List all Patient's Lab Report");
            Console.WriteLine("19. Search Patient's Lab Report By Id");
            Console.WriteLine("20. Delete Patient's Lab Report Details");
            Console.WriteLine("21. Exit\n");
        }

        private static void AddPatient()
        {
            try
            {
                Patient newPatient = new Patient();
                Console.WriteLine("Enter Patient ID :");
                newPatient.PatientId = Console.ReadLine();
                Console.WriteLine("Enter Patient Name :");
                newPatient.PatientName = Console.ReadLine();
                Console.WriteLine("Enter Age :");
                newPatient.Age = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Weight :");
                newPatient.Weight = float.Parse(Console.ReadLine());
                Console.WriteLine("Enter Gender('M' for Male and 'F' for Female :");
                newPatient.Gender = Convert.ToChar(Console.ReadLine());
                Console.WriteLine("Enter Address :");
                newPatient.Address = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newPatient.PhoneNo = Console.ReadLine();
                Console.WriteLine("Enter Disease :");
                newPatient.Disease = Console.ReadLine();
                Console.WriteLine("Enter Doctor Id :");
                newPatient.DoctorId = Console.ReadLine();
                bool patientAdded = HMS_BAL.AddPatientBLL(newPatient);
                if (patientAdded)
                {
                    Console.WriteLine("Patient Added Successfully..!");
                }
                else
                {
                    Console.WriteLine("Patient Not Added");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddPatientAppointmentData()
        {
            try
            {
                Appointment newAppointment = new Appointment();
                Console.WriteLine("Enter Appointment ID :");
                newAppointment.AppointmentId = Console.ReadLine();
                Console.WriteLine("Enter Patient ID :");
                newAppointment.PatientId = Console.ReadLine();
                Console.WriteLine("Enter doctor Name :");
                newAppointment.DoctorName = Console.ReadLine();
                Console.WriteLine("Enter Room Number :");
                newAppointment.RoomNo = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter date of visit :");
                newAppointment.DateOfVisit = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Admission date :");
                newAppointment.AdmissionDate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter discharge date :");
                newAppointment.DischargeDate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter remarks :");
                newAppointment.Remarks = Console.ReadLine();
                bool patientAppointmentDataAdded = HMS_BAL.AddPatientAppointmentDataBLL(newAppointment);
                if (patientAppointmentDataAdded)
                    Console.WriteLine("Patient's Appointment Details Added");
                else
                    Console.WriteLine("Patient's Appointment Details not Added");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllPatients()
        {
            try
            {
                List<Patient> patientList = HMS_BAL.GetAllPatientsBLL();
                if (patientList != null && patientList.Count > 0)
                {
                    foreach (Patient patient in patientList)
                    {
                        Console.WriteLine("******************************************************************************************");
                        Console.WriteLine("Patient Id     :" + patient.PatientId);
                        Console.WriteLine("Patient Name   :" + patient.PatientName);
                        Console.WriteLine("Age            :" + patient.Age);
                        Console.WriteLine("Weight         :" + patient.Weight);
                        Console.WriteLine("Gender         :" + patient.Gender);
                        Console.WriteLine("Address        :" + patient.Address);
                        Console.WriteLine("Phone Number   :" + patient.PhoneNo);
                        Console.WriteLine("Disease        :" + patient.Disease);
                        Console.WriteLine("Doctor Id      :" + patient.DoctorId);
                        Console.WriteLine("******************************************************************************************");
                    }
                }
                else
                {
                    Console.WriteLine("**********No Patient Details AvaiLable**********");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllPatientAppointmentData()
        {
            try
            {
                List<Appointment> appointmentList = HMS_BAL.GetAllPatientsAppointmentDataBAL();
                if (appointmentList != null && appointmentList.Count > 0)
                {

                    foreach (Appointment appointment in appointmentList)
                    {
                        Console.WriteLine("******************************************************************************************");
                        Console.WriteLine("AppointmentId :" + appointment.AppointmentId);
                        Console.WriteLine("Patient Id    :" + appointment.PatientId);
                        Console.WriteLine("Doctor Name   :" + appointment.DoctorName);
                        Console.WriteLine("Room Number   :" + appointment.RoomNo);
                        Console.WriteLine("Date Of Visit :" + appointment.DateOfVisit);
                        Console.WriteLine("Admission Date:" + appointment.AdmissionDate);
                        Console.WriteLine("Discharge Date:" + appointment.DischargeDate);
                        Console.WriteLine("Remarks       :" + appointment.Remarks);
                        Console.WriteLine("******************************************************************************************");
                    }
                }
                else
                {
                    Console.WriteLine("**********No Patient Appointment Details AvaiLable**********");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ModifyPatient()
        {
            try
            {
                string updatePatientID;
                Console.WriteLine("Enter PatientID to Update Details:");
                updatePatientID = Console.ReadLine();
                Patient updatedPatient = HMS_BAL.SearchPatientBAL(updatePatientID);
                if (updatedPatient != null)
                {
                    Console.WriteLine("Update PatientName :");
                    updatedPatient.PatientName = Console.ReadLine();
                    Console.WriteLine("Update Patient's Age:");
                    updatedPatient.Age = int.Parse(Console.ReadLine());
                    Console.WriteLine("Update Patient's Weight:");
                    updatedPatient.Weight = float.Parse(Console.ReadLine());
                    Console.WriteLine("Update Patient gender :");
                    updatedPatient.Gender = Convert.ToChar(Console.ReadLine());
                    Console.WriteLine("Update Address :");
                    updatedPatient.Address = Console.ReadLine();
                    Console.WriteLine("Update Phone Number :");
                    updatedPatient.PhoneNo = Console.ReadLine();
                    Console.WriteLine("Update Disease :");
                    updatedPatient.Disease = Console.ReadLine();
                    bool patientUpdated = HMS_BAL.UpdatePatientBAL(updatedPatient);
                    if (patientUpdated)
                        Console.WriteLine("Patient Details Updated Successfully");
                    else
                        Console.WriteLine("**********Patient Details Not Updated**********");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details AvaiLable**********");
                }


            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchPatientByID()
        {
            try
            {
                string searchPatientID;
                Console.WriteLine("Enter PatientID to Search:");
                searchPatientID = Console.ReadLine();
                Patient searchPatient = HMS_BAL.SearchPatientBAL(searchPatientID);
                if (searchPatient != null)
                {
                    Console.WriteLine("******************************************************************************************");
                    Console.WriteLine("Patient Id     :" + searchPatient.PatientId);
                    Console.WriteLine("Patient Name   :" + searchPatient.PatientName);
                    Console.WriteLine("Age            :" + searchPatient.Age);
                    Console.WriteLine("Weight         :" + searchPatient.Weight);
                    Console.WriteLine("Gender         :" + searchPatient.Gender);
                    Console.WriteLine("Address        :" + searchPatient.Address);
                    Console.WriteLine("Phone Number   :" + searchPatient.PhoneNo);
                    Console.WriteLine("Disease        :" + searchPatient.Disease);
                    Console.WriteLine("Doctor Id      :" + searchPatient.DoctorId);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details AvaiLable**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void SearchPatientByDoctorName()
        {
            try
            {
                string searchPatientByDoctor;
                Console.WriteLine("Enter Doctor's name to search:");
                searchPatientByDoctor = Console.ReadLine();
                Appointment searchPatientdoc = HMS_BAL.SearchPatientByDoctorBAL(searchPatientByDoctor);
                if (searchPatientdoc != null)
                {
                    Console.WriteLine("******************************************************************************************");
                    Console.WriteLine("AppointmentId :" + searchPatientdoc.AppointmentId);
                    Console.WriteLine("PatientId     :" + searchPatientdoc.PatientId);
                    Console.WriteLine("Doctor Name   :" + searchPatientdoc.DoctorName);
                    Console.WriteLine("Room Number   :" + searchPatientdoc.RoomNo);
                    Console.WriteLine("Date Of Visit :" + searchPatientdoc.DateOfVisit);
                    Console.WriteLine("Admission Date:" + searchPatientdoc.AdmissionDate);
                    Console.WriteLine("Discharge Date:" + searchPatientdoc.DischargeDate);
                    Console.WriteLine("Remarks       :" + searchPatientdoc.Remarks);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details AvaiLable**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void SearchPatientByDoctorDOV()
        {
            try
            {
                DateTime searchPatientDOV;
                Console.WriteLine("Enter Date of visit to search:");
                searchPatientDOV = Convert.ToDateTime(Console.ReadLine());
                Appointment searchPatientdov = HMS_BAL.SearchPatientDOVBAL(searchPatientDOV);
                if (searchPatientdov != null)
                {
                    Console.WriteLine("******************************************************************************************");
                    Console.WriteLine("AppointmentId :" + searchPatientdov.AppointmentId);
                    Console.WriteLine("PatientId     :" + searchPatientdov.PatientId);
                    Console.WriteLine("Doctor Name   :" + searchPatientdov.DoctorName);
                    Console.WriteLine("Room Number   :" + searchPatientdov.RoomNo);
                    Console.WriteLine("Date Of Visit :" + searchPatientdov.DateOfVisit);
                    Console.WriteLine("Admission Date:" + searchPatientdov.AdmissionDate);
                    Console.WriteLine("Discharge Date:" + searchPatientdov.DischargeDate);
                    Console.WriteLine("Remarks       :" + searchPatientdov.Remarks);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details AvaiLable**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
        private static void SearchPatientByDoctorDOA()
        {
            try
            {
                DateTime searchPatientDOA;
                Console.WriteLine("Enter Date of admission to search:");
                searchPatientDOA = Convert.ToDateTime(Console.ReadLine());
                Appointment searchPatientdoa = HMS_BAL.SearchPatientDOABAL(searchPatientDOA);
                if (searchPatientdoa != null)
                {
                    Console.WriteLine("******************************************************************************************");
                    Console.WriteLine("AppointmentId :" + searchPatientdoa.AppointmentId);
                    Console.WriteLine("PatientId     :" + searchPatientdoa.PatientId);
                    Console.WriteLine("Doctor Name   :" + searchPatientdoa.DoctorName);
                    Console.WriteLine("Room Number   :" + searchPatientdoa.RoomNo);
                    Console.WriteLine("Date Of Visit :" + searchPatientdoa.DateOfVisit);
                    Console.WriteLine("Admission Date:" + searchPatientdoa.AdmissionDate);
                    Console.WriteLine("Discharge Date:" + searchPatientdoa.DischargeDate);
                    Console.WriteLine("Remarks       :" + searchPatientdoa.Remarks);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details AvaiLable**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void SearchPatientByDoctorDOD()
        {
            try
            {
                DateTime searchPatientDOD;
                Console.WriteLine("Enter Date of discharge to search:");
                searchPatientDOD = Convert.ToDateTime(Console.ReadLine());
                Appointment searchPatientdod = HMS_BAL.SearchPatientDODBAL(searchPatientDOD);
                if (searchPatientdod != null)
                {
                    Console.WriteLine("******************************************************************************************");
                    Console.WriteLine("AppointmentId :" + searchPatientdod.AppointmentId);
                    Console.WriteLine("PatientId     :" + searchPatientdod.PatientId);
                    Console.WriteLine("Doctor Name   :" + searchPatientdod.DoctorName);
                    Console.WriteLine("Room Number   :" + searchPatientdod.RoomNo);
                    Console.WriteLine("Date Of Visit :" + searchPatientdod.DateOfVisit);
                    Console.WriteLine("Admission Date:" + searchPatientdod.AdmissionDate);
                    Console.WriteLine("Discharge Date:" + searchPatientdod.DischargeDate);
                    Console.WriteLine("Remarks       :" + searchPatientdod.Remarks);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details AvaiLable**********");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void DeletePatient()
        {
            try
            {
                string deletePatientID;
                Console.WriteLine("Enter PatientID to Delete:");
                deletePatientID = Console.ReadLine();
                bool patientdeleted = HMS_BAL.DeletePatientBAL(deletePatientID);
                if (patientdeleted)
                    Console.WriteLine("Patient Deleted");
                else
                    Console.WriteLine("Patient not Deleted ");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeletePatientAppointmentDetails()
        {
            try
            {
                string deletePatientAppointmentID;
                Console.WriteLine("Enter AppointmentID to Delete:");
                deletePatientAppointmentID = Console.ReadLine();
                bool patientAppointmentdeleted = HMS_BAL.DeletePatientAppointmentDetailsBAL(deletePatientAppointmentID);
                if (patientAppointmentdeleted)
                    Console.WriteLine("Patient's Appointment Details Deleted");
                else
                    Console.WriteLine("Patient's Appointment Details not Deleted ");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeletePatientBill()
        {
            try
            {
                string deletePatientBillId;
                Console.WriteLine("Enter Patient's Bill ID to Delete:");
                deletePatientBillId = Console.ReadLine();
                bool patientBillDeleted = HMS_BAL.DeletePatientBillBAL(deletePatientBillId);
                if (patientBillDeleted)
                    Console.WriteLine("Patient's Bill Details Deleted");
                else
                    Console.WriteLine("Patient's Bill Details not Deleted ");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeletePatientLabReport()
        {
            try
            {
                string deletePatientLabReportId;
                Console.WriteLine("Enter Patient's Lab Report ID to Delete:");
                deletePatientLabReportId = Console.ReadLine();
                bool patientLabReportDeleted = HMS_BAL.DeletePatientLabReportBAL(deletePatientLabReportId);
                if (patientLabReportDeleted)
                    Console.WriteLine("Patient's Lab Report Details Deleted");
                else
                    Console.WriteLine("Patient's Lab Report Details not Deleted ");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddBillReport()

        {

            string PatType;

            Console.WriteLine("Enter Inpatient or OutPatient :");

            PatType = Console.ReadLine();

            try

            {

                if (PatType == "IP")

                {

                    Bill newBill = new Bill();

                    Console.WriteLine("Enter Bill ID :");

                    newBill.BillId = Console.ReadLine();

                    Console.WriteLine("Enter Patient ID :");

                    newBill.PatientId = Console.ReadLine();

                    Console.WriteLine("Enter Doctor Fees :");

                    newBill.DoctorFees = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter Room Charges :");

                    newBill.RoomCharges = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter Operation Charges :");

                    newBill.OperationCharges = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter Medical bill :");

                    newBill.MedicineFees = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter TotalDays :");

                    newBill.TotalDays = Convert.ToInt16(Console.ReadLine());

                    Console.WriteLine("Enter Lab Fees :");

                    newBill.LabFees = Convert.ToDouble(Console.ReadLine());

                    bool patientLabReportDataAdded = HMS_BAL.AddPatientBillBAL(newBill);

                    if (patientLabReportDataAdded)

                        Console.WriteLine("Bill report Added");

                    else

                        Console.WriteLine("Bill report not Added");

                }

                else if (PatType == "OP")

                {

                    Bill newBill = new Bill();

                    Console.WriteLine("Enter Bill ID :");

                    newBill.BillId = Console.ReadLine();

                    Console.WriteLine("Enter Patient ID :");

                    newBill.PatientId = Console.ReadLine();

                    Console.WriteLine("Enter Doctor Fees :");

                    newBill.RoomCharges = 0;

                    newBill.OperationCharges = 0;

                    newBill.TotalDays = 0;

                    newBill.DoctorFees = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter Medical bill :");

                    newBill.MedicineFees = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter Lab Fees :");

                    newBill.LabFees = Convert.ToDouble(Console.ReadLine());

                    bool patientLabReportDataAdded = HMS_BAL.AddPatientBillBAL(newBill);

                    if (patientLabReportDataAdded)

                        Console.WriteLine("Bill report Added");

                    else

                        Console.WriteLine("Bill report not Added");

                }

                else

                {

                    Console.WriteLine("Enter correct patient type");

                }

            }

            catch (HMS_Exception ex)

            {

                Console.WriteLine(ex.Message);

            }

            Console.ReadKey();



        }

        private static void ListAllBill()
        {
            try
            {
                List<Bill> billList = HMS_BAL.GetAllPatientBillBAL();
                if (billList != null && billList.Count > 0)
                {

                    foreach (Bill bill in billList)
                    {
                        Console.WriteLine("**********BILL GENERATIONS**********");
                        Console.WriteLine("Bill Id                          :" + bill.BillId);
                        Console.WriteLine("Patient Id                       :" + bill.PatientId);
                        //Console.WriteLine("Patient Type                     :" + bill.PatientType);
                        //Console.WriteLine("Doctor Id                        :" + bill.DoctorId);
                        Console.WriteLine("Doctor Fees                      :" + bill.DoctorFees);
                        Console.WriteLine("Room Amount                      :" + bill.RoomCharges);
                        Console.WriteLine("Operation Theatre Amount         :" + bill.OperationCharges);
                        Console.WriteLine("Medical Bill                     :" + bill.MedicineFees);
                        Console.WriteLine("Total Days                       :" + bill.TotalDays);
                        Console.WriteLine("Lab Bill                         :" + bill.LabFees);
                        Console.WriteLine("------------------------------------------------------------------------------------------");
                        Console.WriteLine("Total amount to be Paid          :" + (bill.DoctorFees + bill.RoomCharges + bill.OperationCharges + bill.MedicineFees + bill.LabFees));
                        Console.WriteLine("------------------------------------------------------------------------------------------");
                        Console.WriteLine("******************************************************************************************");
                    }
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("**********No Bill Details AvaiLable**********");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddLabReport()
        {
            try
            {
                LabReport Lab = new LabReport();
                Console.WriteLine("Enter Report ID :");
                Lab.LabId = Console.ReadLine();
                Console.WriteLine("Enter Patient ID :");
                Lab.PatientId = Console.ReadLine();
                Console.WriteLine("Enter Doctor ID :");
                Lab.DoctorId = Console.ReadLine();
                Console.WriteLine("Enter Test date :");
                Lab.TestDate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Test type :");
                Lab.TestType = (Console.ReadLine());
                Console.WriteLine("Enter Patient Type :");
                Lab.PatientType = (Console.ReadLine());
                bool patientLabReportAdded = HMS_BAL.AddPatientLabReportBAL(Lab);
                if (patientLabReportAdded)
                    Console.WriteLine("Lab report Added");
                else
                    Console.WriteLine("**********Lab report not Added**********");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void ListAllLabReport()
        {
            try
            {
                List<LabReport> LabList = HMS_BAL.GetAllPatientLabReportBAL();
                if (LabList != null && LabList.Count > 0)
                {

                    foreach (LabReport Lab in LabList)
                    {
                        Console.WriteLine("**********Lab REPORTS**********");
                        Console.WriteLine("Report Id    :" + Lab.LabId);
                        Console.WriteLine("Patient Id   :" + Lab.PatientId);
                        Console.WriteLine("Doctor Id    :" + Lab.DoctorId);
                        Console.WriteLine("TestDate     :" + Lab.TestDate);
                        Console.WriteLine("TestType     :" + Lab.TestType);
                        Console.WriteLine("Patient Type :" + Lab.PatientType);
                        Console.WriteLine("**********************************");
                    }
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("**********No Lab report AvaiLable**********");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchBillByID()
        {
            try
            {
                string searchBillID;
                Console.WriteLine("Enter Bill ID to Search:");
                searchBillID = Console.ReadLine();
                Bill searchbill = HMS_BAL.SearchBillByIdBAL(searchBillID);
                if (searchbill != null)
                {
                    Console.WriteLine("**********BILL GENERATION**********");
                    Console.WriteLine("**********BILL GENRATIONS**********");
                    Console.WriteLine("Bill Id                          :" + searchbill.BillId);
                    Console.WriteLine("Patient Id                       :" + searchbill.PatientId);
                    Console.WriteLine("Patient Type                     :" + searchbill.PatientType);
                    Console.WriteLine("Doctor Id                        :" + searchbill.DoctorId);
                    Console.WriteLine("Doctor Fees                      :" + searchbill.DoctorFees);
                    Console.WriteLine("Room Amount                      :" + searchbill.RoomCharges);
                    Console.WriteLine("Operation Theatre Amount         :" + searchbill.OperationCharges);
                    Console.WriteLine("Medical Bill                     :" + searchbill.MedicineFees);
                    Console.WriteLine("Total Days                       :" + searchbill.TotalDays);
                    Console.WriteLine("Lab Bill                         :" + searchbill.LabFees);
                    Console.WriteLine("------------------------------------------------------------------------------------------");
                    Console.WriteLine("Total amount to be Paid          :" + (searchbill.DoctorFees + searchbill.RoomCharges + searchbill.OperationCharges + searchbill.MedicineFees + searchbill.LabFees));
                    Console.WriteLine("------------------------------------------------------------------------------------------");
                    Console.WriteLine("***************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Bill Details AvaiLable**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void SearchReportById()
        {
            try
            {
                string searchReportID;
                Console.WriteLine("Enter ReportID to Search:");
                searchReportID = Console.ReadLine();
                LabReport searchreport = HMS_BAL.SearchReportByIdBAL(searchReportID);
                if (searchreport != null)
                {
                    Console.WriteLine("**********Lab REPORTS**********");
                    Console.WriteLine("Report Id    :" + searchreport.LabId);
                    Console.WriteLine("Patient Id   :" + searchreport.PatientId);
                    Console.WriteLine("Doctor Id    :" + searchreport.DoctorId);
                    Console.WriteLine("TestDate     :" + searchreport.TestDate);
                    Console.WriteLine("TestType     :" + searchreport.TestType);
                    Console.WriteLine("Patient Type :" + searchreport.PatientType);
                    Console.WriteLine("*******************************");
                }
                else
                {
                    Console.WriteLine("**********No Report Details AvaiLable**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
        private static void SetSerialization()
        {
            HMS_BAL.SetSerialization();
        }

    }
}
    

