﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntities
{
    [Serializable]
    public class Patient
    {
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public int Age { get; set; }
        public float Weight { get; set; }
        public char Gender { get; set; }
        public string Address { get; set; }
        public string PhoneNo { get; set; }
        public string Disease { get; set; }
        public string DoctorId { get; set; }
    }
}
