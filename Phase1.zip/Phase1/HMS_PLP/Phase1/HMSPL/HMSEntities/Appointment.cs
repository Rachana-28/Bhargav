﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntities
{
    [Serializable]
    public class Appointment
    {

        public string AppointmentId { get; set; }
        public string PatientId { get; set; }
        public string DoctorName { get; set; }
        public int RoomNo { get; set; }
        public DateTime DateOfVisit { get; set; }
        public DateTime AdmissionDate { get; set; }
        public DateTime DischargeDate { get; set; }
        public string Remarks { get; set; }
    }
}
